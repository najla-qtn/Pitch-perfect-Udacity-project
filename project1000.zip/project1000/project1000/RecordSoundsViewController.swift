//
//  RecordSoundsViewController.swift
//  project1000
//
//  Created by Najla Al qahtani on 11/9/18.
//  Copyright © 2018 Najla Al qahtani. All rights reserved.
//

import UIKit
import AVFoundation

/*
 Remember that protocols act as a kind of contract. AVAudioRecorder does not know what classes you have in your app. However, if you say that your class conforms to the AVAudioRecorderDelegate protocol, then it knows it can call a specific function in your class.
 
 The specific function has been defined in the protocol (in this case, the AVAudioRecorderDelegate protocol). This way your class and the AVAudioRecorder are loosely coupled, and they can work together without having to know much about each other.
 
 Loose coupling of classes is really useful in building interchangeable pieces of code, and used quite a lot in iOS.
 الانهرتنس ممكن يصير من كلاس واحد فقط بينما البروتوكول ممكن يصير من مجموعة من الكلاسات
 */
class RecordSoundsViewController: UIViewController, AVAudioRecorderDelegate {
    
    // MARK: Properties
    
    var audioRecorder: AVAudioRecorder!
    
    @IBOutlet weak var recordingButton: UIButton!
    @IBOutlet weak var stopRecordingButton: UIButton!
    @IBOutlet weak var recordingLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    stopRecordingButton.isEnabled=false
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
      
    }
   
    @IBAction func recordAudio(_ sender: Any) {
        /*
        recordingLabel.text="Recording in progress"
        stopRecordingButton.isEnabled=true
        recordingButton.isEnabled=false
        */
        configureUI(playStatus: true)
        //record directory folder
        let dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask, true)[0] as String
        //record file name
        let recordingName = "recordedVoice.wav"
        //name+dir=path
        let pathArray = [dirPath, recordingName]
        let filePath = URL(string: pathArray.joined(separator: "/"))
        print(filePath as Any)
        
        //play and stop recording
        let session = AVAudioSession.sharedInstance()
        try! session.setCategory(AVAudioSession.Category.playAndRecord,mode: .default ,options: AVAudioSession.CategoryOptions.defaultToSpeaker)
      
        try! audioRecorder = AVAudioRecorder(url: filePath!, settings: [:])
        //الاوديوركوردر حطيته مفوض عن الكلاس اللي سويته منه
        audioRecorder.delegate=self
        audioRecorder.isMeteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
    }
    
    @IBAction func stopRecording(_ sender: Any) {
        /*
        recordingButton.isEnabled=true
        stopRecordingButton.isEnabled=false
        recordingLabel.text="Tap to record"
        */
        configureUI(playStatus: false)
        audioRecorder.stop()
        let audioSession=AVAudioSession.sharedInstance()
        try! audioSession.setActive(false)
    }
    
   //funct we are going to use to stop recording segue which means moving between view controllers
    //هذي الفنكشن اللي سويناها هنا بترسل المقطع عبر السقوي
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        //بنرسل باث الملف مع السقوي اللي اسمه ستوب ريكوردنق
        if flag{
       performSegue(withIdentifier: "stopRecording", sender: audioRecorder.url)
        }else{
           print("recording was not succssful")
        }
    }
            /*before Storyboard executes the segue, it will call our RecordSoundsViewController to prepare for that segue. In preparing, the RecordSoundsViewController will store away the path to the recorded audio.*/
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier=="stopRecording"{
        //البلاي ساوند هو الفيوكنترولر اللي احنا متجهين له سوينا منه اوبجكت
            let playSoundsVC=segue.destination as! PlaySoundsViewController
            //خرنا اليورل حق الفديو في المتغير هذا
            let recordedAudioURL=sender as! URL
            //ساوينا المتغير اللي خزنا فيه اليورل بالمتغير الموجود في الكلاس حق الفيو كونترولر الجديد
            playSoundsVC.recordedAudioURL=recordedAudioURL
        }
        
    }
    func configureUI(playStatus: Bool){
        switch (playStatus){
        case true:
            recordingLabel.text="Recording in progress"
            stopRecordingButton.isEnabled=true
            recordingButton.isEnabled=false
        case false:
            recordingButton.isEnabled=true
            stopRecordingButton.isEnabled=false
            recordingLabel.text="Tap to record"
        }
    }
}

